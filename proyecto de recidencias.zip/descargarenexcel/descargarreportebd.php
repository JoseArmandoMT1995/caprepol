<?php
///// INCLUIR LA CONEXIÓN A LA BD /////////////////
include('conexion.php');
///// CONSULTA A LA BASE DE DATOS /////////////////
$convenio="SELECT * FROM convenio order by idConvenio";
$resConv=$conexion->query($convenio);
?>

<?php include_once 'header.php'; ?>


<br>
<br>
<br>
 <H2>DESCARGA DE REPORTES</H2><BR>
    

		<section>
			<table class="table">
				<tr class="bg-primary">
					<th>idConvenio</th>
					<th>NombreEscuela</th>
					<th>Carreras</th>
					<th>Vigencia</th>
				
				</tr>
				<?php
				while ($registroConvenio = $resConv->fetch_array(MYSQLI_BOTH))
				{
					echo'<tr>
						 <td>'.$registroConvenio['idConvenio'].'</td>
						 <td>'.$registroConvenio['NombreEscuela'].'</td>
						 <td>'.$registroConvenio['Carreras'].'</td>
						 <td>'.$registroConvenio['Vigencia'].'</td>
						
						 </tr>';
				}
				?>
			</table>
		</section>

		<form method="post" class="form" action="reporte.php">
		<input type="date" name="fecha1">
		<input type="date" name="fecha2">
		<input type="submit" name="generar_reporte">
		</form>

<br>
<br>
<br>
 <ol class="breadcrumb">
<li><a class="btn btn-primary" href="/ProyectodeResidencias/?c=convenio">Ir a Pagina Convenios</a>
<li><a class="btn btn-primary" href="/ProyectodeResidencias/?c=prestador">Ir a Pagina Prestadores</a>
<li><a class="btn btn-primary" href="/ProyectodeResidencias/SistemaAsistencia/index.php">Checador</a>

	</ol>



	</body>
</html>


<?php include_once 'footer.php'; ?>

